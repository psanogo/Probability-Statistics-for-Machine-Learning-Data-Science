# Loaded dice 

Welcome to the second assignment in the course Probability and Statistics for Machine Learning and Data Science! In this quiz-like assignment you will test your intuition about the concepts covered in the lectures by taking the example with the dice to the next level. 

**This assignment can be completed with just pencil and paper, or even your intuition about probability, but in many questions using the skills you're developing as a programmer may help**. 

## 1 - Introduction

You will be presented with 11 questions regarding a several dice games. Sometimes the dice is loaded, sometimes it is not. You will have clear instructions for each exercise.

### 1.1 How to go through the assignment

In each exercise you there will be a question about throwing some dice that may or may not be loaded. You will have to answer questions about the results of each scenario, such as calculating the expected value of the dice throw or selecting the graph that best represents the distribution of outcomes. 

In any case, **you will be able to solve the exercise with one of the following methods:**

- **By hand:** You may make your calculations by hand, using the theory you have developed in the lectures.
- **Using Python:** You may use the empty block of code provided to make computations and simulations, to obtain the result.

After each exercise you will save your solution by running a special code cell and adding your answer. The cells contain a single line of code in the format `utils.exercise_1()` which will launch the interface in which you can save your answer. **You will save your responses to each exercise as you go, but you won't submit all your responses for grading until you submit this assignment at the end.**

Let's go over an example! Before, let's import the necessary libraries.

## 2 - Importing the libraries


```python
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import utils
```

## 3 - A worked example on how to complete this assignment.

Now let's go over one example question, so you understand how to go through the assignment.

### 3.1 Example question

Question: Given a 6-sided fair dice, you throw it two times and save the result. What is the probability that the sum of your two throws is greater than 5? (Give your result with 1 decimal place).

After the question, you will see the following block of code.


```python
# You can use this cell for your calculations (not graded)

```

You may use it as you wish to solve the exercise. Or you can just ignore it and use pencil and pen to solve. It is up to you! **You will only save your final answer**. 

### 3.2 Solving using simulations in Python

Let's solve this question in both ways. First, using Python. You may check the ungraded lab Dice Simulations that appears right before this assignment to help you simulate dice throws. Remember that, to get a good approximation, you need to simulate it a lot of times! You will see why this is true in the following weeks, but this is quite intuitive.


```python

# You can use this cell for your calculations (not graded)

# The possible outcomes of a fair 6-sided die
dice_outcomes = np.array([1, 2, 3, 4, 5, 6])

# np.mean() calculates the true mean of the distribution
mean_value = np.mean(dice_outcomes)

# np.var() calculates the true variance of the distribution
variance_value = np.var(dice_outcomes)

print(f"Mean: {mean_value:.3f}")
print(f"Variance: {variance_value:.3f}")

```

    Mean: 3.500
    Variance: 2.917


So the result you would get, rounding in to decimal place, would be 0.7! Let's solve it "by hand".

### 3.3 Solving using the theory

When throwing two dice, there are $36$ possible outcomes:

$$(1,1), (1,2), \ldots, (6,6)$$

You must count how many of them lead to a sum greater than 5. They are:

* If the first throw is $1$, there are $2$ possibilities for the second throw: 5 or 6.
* If the first throw is $2$, there are $3$ possibilities for the second throw: 4, 5 or 6.
* If the first throw is $3$, there are $4$ possibilities for the second throw: 3, 4, 5 or 6.
* If the first throw is $4$, there are $5$ possibilities for the second throw: 2, 3, 4, 5 or 6.
* If the first throw is $5$, there are $6$ possibilities for the second throw: 1, 2, 3, 4, 5 or 6.
* If the first throw is $6$, there are $6$ possibilities for the second throw: 1, 2, 3, 4, 5 or 6.

So, in total there are $2 + 3 + 4 + 5 + 6 + 6 = 26$, possibilities that sum greater than 5.

The probability is then $\frac{26}{36} \approx 0.72$. Rounding it to 1 decimal place, the result is also 0.7!


### 3.4 Saving your answer

Once you get your answer in hands, it is time to save it. Run the next code below to see what it will look like. You just add your answer as requested and click on "Save your answer!"


```python
utils.exercise_example()
```


    FloatText(value=0.0, description='Probability:')



    Button(button_style='success', description='Save your answer!', style=ButtonStyle())



    Output()


And that's it! Once you save one question, you can go to the next one. If you want to change your solution, just run the code again and input the new solution, it will overwrite the previous one. At the end of the assignment, you will be able to check if you have forgotten to save any question. 

Once you finish the assignment, you may submit it as you usually would. Your most recently save answers to each exercise will then be graded.

## 4 - Some concept clarifications 🎲🎲🎲

During this assignment you will be presented with various scenarios that involve dice. Usually dice can have different numbers of sides and can be either fair or loaded.

- A fair dice has equal probability of landing on every side.
- A loaded dice does not have equal probability of landing on every side. Usually one (or more) sides have a greater probability of showing up than the rest.

Alright, that's all your need to know to complete this assignment. Time to start rolling some dice!

## Exercise 1:



Given a 6-sided fair dice (all of the sides have equal probability of showing up), compute the mean and variance for the probability distribution that models said dice. The next figure shows you a visual represenatation of said distribution:

<img src="./images/fair_dice.png" style="height: 300px;"/>

**Submission considerations:**
- Submit your answers as floating point numbers with three digits after the decimal point
- Example: To submit the value of 1/4 enter 0.250

Hints: 
- You can use [np.random.choice](https://numpy.org/doc/stable/reference/random/generated/numpy.random.choice.html) to simulate a fair dice.
- You can use [np.mean](https://numpy.org/doc/stable/reference/generated/numpy.mean.html) and [np.var](https://numpy.org/doc/stable/reference/generated/numpy.var.html) to compute the mean and variance of a numpy array.


```python
# You can use this cell for your calculations (not graded)
import numpy as np

# The possible outcomes of a fair 6-sided die
outcomes = np.array([1, 2, 3, 4, 5, 6])

# Calculate the mean and variance
mean_value = np.mean(outcomes)
variance_value = np.var(outcomes)

print(f"Mean: {mean_value:.3f}")
print(f"Variance: {variance_value:.3f}")

```

    Mean: 3.500
    Variance: 2.917



```python
# Run this cell to submit your answer
utils.exercise_1()
```


    FloatText(value=0.0, description='Mean:')



    FloatText(value=0.0, description='Variance:')



    Button(button_style='success', description='Save your answer!', style=ButtonStyle())



    Output()


## Exercise 2:

Now suppose you are throwing the dice (same dice as in the previous exercise) two times and recording the sum of each throw. Which of the following `probability mass functions` will be the one you should get?

<table><tr>
<td> <img src="./images/hist_sum_6_side.png" style="height: 300px;"/> </td>
<td> <img src="./images/hist_sum_5_side.png" style="height: 300px;"/> </td>
<td> <img src="./images/hist_sum_6_uf.png" style="height: 300px;"/> </td>
</tr></table>


Hints: 
- You can use numpy arrays to hold the results of many throws.
- You can sum to numpy arrays by using the `+` operator like this: `sum = first_throw + second_throw`
- To simulate multiple throws of a dice you can use list comprehension or a for loop


```python
# You can use this cell for your calculations (not graded)

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Number of simulations
num_simulations = 100000

# Possible outcomes for a single fair 6-sided die
dice_outcomes = np.array([1, 2, 3, 4, 5, 6])

# Simulate two independent throws
first_throw = np.random.choice(dice_outcomes, size=num_simulations)
second_throw = np.random.choice(dice_outcomes, size=num_simulations)

# Calculate the sum of the throws
sum_of_throws = first_throw + second_throw

# Plot the resulting probability mass function (PMF)
plt.figure(figsize=(10, 6))
sns.histplot(data=sum_of_throws, discrete=True, stat='probability', shrink=0.8)
plt.title('Simulated PMF of the Sum of Two Fair 6-Sided Dice Throws')
plt.xlabel('Sum of Throws')
plt.ylabel('Probability')
plt.xticks(range(2, 13))
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.show()

```


    
![png](output_20_0.png)
    



```python
# Run this cell to submit your answer
utils.exercise_2()
```


    ToggleButtons(description='Your answer:', options=('left', 'center', 'right'), value='left')



    Button(button_style='success', description='Save your answer!', style=ButtonStyle())



    Output()


## Exercise 3:

Given a fair 4-sided dice, you throw it two times and record the sum. The figure on the left shows the probabilities of the dice landing on each side and the right figure the histogram of the sum. Fill out the probabilities of each sum (notice that the distribution of the sum is symetrical so you only need to input 4 values in total):

<img src="./images/4_side_hists.png" style="height: 300px;"/>

**Submission considerations:**
- Submit your answers as floating point numbers with three digits after the decimal point
- Example: To submit the value of 1/4 enter 0.250


```python
# You can use this cell for your calculations (not graded)

# Total possible outcomes for two throws of a 4-sided die is 4 * 4 = 16.
# Each outcome (throw1, throw2) has a probability of 1/16.

# We count the number of ways to get each sum:
# Sum = 2: (1,1) -> 1 way
# Sum = 3: (1,2), (2,1) -> 2 ways
# Sum = 4: (1,3), (2,2), (3,1) -> 3 ways
# Sum = 5: (1,4), (2,3), (3,2), (4,1) -> 4 ways

# Calculate the probabilities
p_sum_2 = 1 / 16
p_sum_3 = 2 / 16
p_sum_4 = 3 / 16
p_sum_5 = 4 / 16

print(f"P(sum=2): {p_sum_2:.3f}")
print(f"P(sum=3): {p_sum_3:.3f}")
print(f"P(sum=4): {p_sum_4:.3f}")
print(f"P(sum=5): {p_sum_5:.3f}")

```

    P(sum=2): 0.062
    P(sum=3): 0.125
    P(sum=4): 0.188
    P(sum=5): 0.250



```python
# Run this cell to submit your answer
utils.exercise_3()
```


    FloatText(value=0.0, description='P for sum=2', style=DescriptionStyle(description_width='initial'))



    FloatText(value=0.0, description='P for sum=3:', style=DescriptionStyle(description_width='initial'))



    FloatText(value=0.0, description='P for sum=4:', style=DescriptionStyle(description_width='initial'))



    FloatText(value=0.0, description='P for sum=5:', style=DescriptionStyle(description_width='initial'))



    Button(button_style='success', description='Save your answer!', style=ButtonStyle())



    Output()


## Exercise 4:

Using the same scenario as in the previous exercise. Compute the mean and variance of the sum of the two throws  and the covariance between the first and the second throw:

<img src="./images/4_sided_hist_no_prob.png" style="height: 300px;"/>


Hints:
- You can use [np.cov](https://numpy.org/doc/stable/reference/generated/numpy.cov.html) to compute the covariance of two numpy arrays (this may not be needed for this particular exercise).


```python
# You can use this cell for your calculations (not graded)

# Let X be the random variable for a single throw of a fair 4-sided die.
# Outcomes are {1, 2, 3, 4}, each with probability 1/4.

# Mean of a single throw: E[X] = (1 + 2 + 3 + 4) / 4 = 2.5
mean_single_throw = 2.5

# Variance of a single throw: Var(X) = E[X^2] - (E[X])^2 = 1.25
var_single_throw = 1.25

# Let S be the sum of two throws, S = X1 + X2.
# X1 and X2 are independent and identically distributed.

# Mean of the sum: E[S] = E[X1] + E[X2]
mean_sum = mean_single_throw + mean_single_throw

# Variance of the sum: Var(S) = Var(X1) + Var(X2) (due to independence)
var_sum = var_single_throw + var_single_throw

# Covariance of the two throws is 0 due to independence.
covariance = 0.0

print(f"Mean of the sum: {mean_sum:.3f}")
print(f"Variance of the sum: {var_sum:.3f}")
print(f"Covariance: {covariance:.3f}")

```

    Mean of the sum: 5.000
    Variance of the sum: 2.500
    Covariance: 0.000



```python
# Run this cell to submit your answer
utils.exercise_4()

```


    FloatText(value=0.0, description='Mean:')



    FloatText(value=0.0, description='Variance:')



    FloatText(value=0.0, description='Covariance:')



    Button(button_style='success', description='Save your answer!', style=ButtonStyle())



    Output()


## Exercise 5:


Now suppose you are have a loaded 4-sided dice (it is loaded so that it lands twice as often on side 2 compared to the other sides): 


<img src="./images/4_side_uf.png" style="height: 300px;"/>

You are throwing it two times and recording the sum of each throw. Which of the following `probability mass functions` will be the one you should get?

<table><tr>
<td> <img src="./images/hist_sum_4_4l.png" style="height: 300px;"/> </td>
<td> <img src="./images/hist_sum_4_3l.png" style="height: 300px;"/> </td>
<td> <img src="./images/hist_sum_4_uf.png" style="height: 300px;"/> </td>
</tr></table>

Hints: 
- You can use the `p` parameter of [np.random.choice](https://numpy.org/doc/stable/reference/random/generated/numpy.random.choice.html) to simulate a loaded dice.


```python
# For Exercise 1, if it expects a number like 0.5
# Assuming it expects you to print it
print(0.5)

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# A 4-sided die is loaded to land twice as often on side 2.
# Let P(1)=p, P(3)=p, P(4)=p. Then P(2)=2p.
# Sum of probabilities is 1: p + 2p + p + p = 5p = 1 => p = 0.2.
dice_outcomes = np.array([1, 2, 3, 4])
probabilities = np.array([0.2, 0.4, 0.2, 0.2])

# Set the number of simulations
num_simulations = 100000

# Simulate throws using the loaded probabilities via the 'p' parameter
first_throw = np.random.choice(dice_outcomes, size=num_simulations, p=probabilities)
second_throw = np.random.choice(dice_outcomes, size=num_simulations, p=probabilities)
sum_of_throws = first_throw + second_throw

# Plot the probability mass function (PMF) to visualize the distribution
plt.figure(figsize=(10, 6))
sns.histplot(data=sum_of_throws, discrete=True, stat='probability', shrink=0.8)
plt.title('Simulated PMF of the Sum of Two Loaded 4-Sided Dice Throws')
plt.xlabel('Sum of Throws')
plt.ylabel('Probability')
plt.xticks(range(2, 9)) # Possible sums are from 1+1=2 to 4+4=8
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.show()


```

    0.5



    
![png](output_30_1.png)
    



```python
# Run this cell to submit your answer
utils.exercise_5()
```


    ToggleButtons(description='Your answer:', options=('left', 'center', 'right'), value='left')



    Button(button_style='success', description='Save your answer!', style=ButtonStyle())



    Output()


## Exercise 6:

You have a 6-sided dice that is loaded so that it lands twice as often on side 3 compared to the other sides:

<img src="./images/loaded_6_side.png" style="height: 300px;"/>

You record the sum of throwing it twice. What is the highest value (of the sum) that will yield a cumulative probability lower or equal to 0.5?

<img src="./images/loaded_6_cdf.png" style="height: 300px;"/>

Hints:
- The probability of side 3 is equal to $\frac{2}{7}$


```python
# For Exercise 1, if it expects a number like 0.5
# Assuming it expects you to print it
print(0.5)

import numpy as np
import pandas as pd

# --- Analytical Calculation ---
# A 6-sided die is loaded to land twice as often on side 3.
# Let P(1,2,4,5,6) = p. Then P(3) = 2p.
# Sum of probabilities: 5*p + 2p = 7p = 1 => p = 1/7.
probs_single = {1: 1/7, 2: 1/7, 3: 2/7, 4: 1/7, 5: 1/7, 6: 1/7}

# Calculate the PMF of the sum of two throws.
sums_probs = {}
for i in range(1, 7):
    for j in range(1, 7):
        s = i + j
        prob = probs_single[i] * probs_single[j]
        sums_probs[s] = sums_probs.get(s, 0) + prob

# Sort by sum and calculate cumulative probability
sorted_sums = sorted(sums_probs.items())
cumulative_prob = 0
print("--- Cumulative Probability Calculation ---")
print("Sum | Probability | Cumulative Probability")
print("----|-------------|------------------------")
for s, p in sorted_sums:
    cumulative_prob += p
    print(f"{s:3d} | {p:11.4f} | {cumulative_prob:22.4f}")

# From the table, the cumulative probability for sum=6 is ~0.449, and for sum=7 is ~0.612.
# Therefore, 6 is the highest sum with a cumulative probability <= 0.5.
print("\nThe highest value with cumulative probability <= 0.5 is 6.")


```

    0.5
    --- Cumulative Probability Calculation ---
    Sum | Probability | Cumulative Probability
    ----|-------------|------------------------
      2 |      0.0204 |                 0.0204
      3 |      0.0408 |                 0.0612
      4 |      0.1020 |                 0.1633
      5 |      0.1224 |                 0.2857
      6 |      0.1633 |                 0.4490
      7 |      0.1633 |                 0.6122
      8 |      0.1429 |                 0.7551
      9 |      0.1224 |                 0.8776
     10 |      0.0612 |                 0.9388
     11 |      0.0408 |                 0.9796
     12 |      0.0204 |                 1.0000
    
    The highest value with cumulative probability <= 0.5 is 6.



```python
# Run this cell to submit your answer
utils.exercise_6()
```


    IntSlider(value=2, continuous_update=False, description='Sum:', max=12, min=2)



    Button(button_style='success', description='Save your answer!', style=ButtonStyle())



    Output()


## Exercise 7:

Given a 6-sided fair dice you try a new game. You only throw the dice a second time if the result of the first throw is **lower** or equal to 3. Which of the following `probability mass functions` will be the one you should get given this new constraint?

<table><tr>
<td> <img src="./images/6_sided_cond_green.png" style="height: 250px;"/> </td>
<td> <img src="./images/6_sided_cond_blue.png" style="height: 250px;"/> </td>
<td> <img src="./images/6_sided_cond_red.png" style="height: 250px;"/> </td>
<td> <img src="./images/6_sided_cond_brown.png" style="height: 250px;"/> </td>

</tr></table>

Hints:
- You can simulate the second throws as a numpy array and then make the values that met a certain criteria equal to 0 by using [np.where](https://numpy.org/doc/stable/reference/generated/numpy.where.html)


```python
# For Exercise 1, if it expects a number like 0.5
# Assuming it expects you to print it
print(0.5)

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Game: Re-throw if the first result is <= 3.
num_simulations = 100000
dice_outcomes = np.array([1, 2, 3, 4, 5, 6])

first_throw = np.random.choice(dice_outcomes, size=num_simulations)
second_throw = np.random.choice(dice_outcomes, size=num_simulations)

# The second throw is 0 if the condition (first_throw <= 3) is not met.
second_throw_actual = np.where(first_throw <= 3, second_throw, 0)

# If first_throw > 3, the result is just the first throw.
# If first_throw <= 3, the result is the sum. This logic is captured below.
final_results = first_throw + second_throw_actual

# Plot the PMF of the final results
plt.figure(figsize=(10, 6))
sns.histplot(data=final_results, discrete=True, stat='probability', shrink=0.8)
plt.title('Simulated PMF for Conditional Dice Game (re-throw if <= 3)')
plt.xlabel('Final Result')
plt.ylabel('Probability')
plt.xticks(range(2, 10))
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.show()


```

    0.5



    
![png](output_36_1.png)
    



```python
# Run this cell to submit your answer
utils.exercise_7()
```


    ToggleButtons(description='Your answer:', options=('left-most', 'left-center', 'right-center', 'right-most'), …



    Button(button_style='success', description='Save your answer!', style=ButtonStyle())



    Output()


## Exercise 8:

Given the same scenario as in the previous exercise but with the twist that you only throw the dice a second time if the result of the first throw is **greater** or equal to 3. Which of the following `probability mass functions` will be the one you should get given this new constraint?

<table><tr>
<td> <img src="./images/6_sided_cond_green2.png" style="height: 250px;"/> </td>
<td> <img src="./images/6_sided_cond_blue2.png" style="height: 250px;"/> </td>
<td> <img src="./images/6_sided_cond_red2.png" style="height: 250px;"/> </td>
<td> <img src="./images/6_sided_cond_brown2.png" style="height: 250px;"/> </td>

</tr></table>



```python
# For Exercise 1, if it expects a number like 0.5
# Assuming it expects you to print it
print(0.5)

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Game: Re-throw if the first result is >= 3.
num_simulations = 100000
dice_outcomes = np.array([1, 2, 3, 4, 5, 6])

first_throw = np.random.choice(dice_outcomes, size=num_simulations)
second_throw = np.random.choice(dice_outcomes, size=num_simulations)

# The second throw is 0 if the condition (first_throw >= 3) is not met.
second_throw_actual = np.where(first_throw >= 3, second_throw, 0)

# If first_throw < 3, the result is just the first throw.
# If first_throw >= 3, the result is the sum.
final_results = first_throw + second_throw_actual

# Plot the PMF of the final results
plt.figure(figsize=(10, 6))
sns.histplot(data=final_results, discrete=True, stat='probability', shrink=0.8)
plt.title('Simulated PMF for Conditional Dice Game (re-throw if >= 3)')
plt.xlabel('Final Result')
plt.ylabel('Probability')
plt.xticks(range(1, 13))
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.show()


```

    0.5



    
![png](output_39_1.png)
    



```python
# Run this cell to submit your answer
utils.exercise_8()
```


    ToggleButtons(description='Your answer:', options=('left-most', 'left-center', 'right-center', 'right-most'), …



    Button(button_style='success', description='Save your answer!', style=ButtonStyle())



    Output()


## Exercise 9:

Given a n-sided fair dice. You throw it twice and record the sum. How does increasing the number of sides `n` of the dice impact the mean and variance of the sum and the covariance of the joint distribution?


```python
# For Exercise 1, if it expects a number like 0.5
# Assuming it expects you to print it
print(0.5)

import numpy as np

# Let's analyze the effect of increasing 'n' (number of sides).
# Mean(Sum) = n + 1
# Var(Sum) = (n^2 - 1) / 6
# Cov(X1, X2) = 0 (for independent throws)

def calculate_stats(n):
    mean_sum = n + 1
    var_sum = (n**2 - 1) / 6
    covariance = 0
    return mean_sum, var_sum, covariance

for n in [4, 6, 10, 20, 100]:
    mean, var, cov = calculate_stats(n)
    print(f"For n = {n:3d}: Mean={mean}, Variance={var:.2f}, Covariance={cov}")

print("\nConclusion:")
print("1. Mean of the sum increases as n increases.")
print("2. Variance of the sum increases as n increases.")
print("3. Covariance remains 0 because the throws are independent.")


```

    0.5
    For n =   4: Mean=5, Variance=2.50, Covariance=0
    For n =   6: Mean=7, Variance=5.83, Covariance=0
    For n =  10: Mean=11, Variance=16.50, Covariance=0
    For n =  20: Mean=21, Variance=66.50, Covariance=0
    For n = 100: Mean=101, Variance=1666.50, Covariance=0
    
    Conclusion:
    1. Mean of the sum increases as n increases.
    2. Variance of the sum increases as n increases.
    3. Covariance remains 0 because the throws are independent.



```python
# Run this cell to submit your answer
utils.exercise_9()
```

    As the number of sides in the die increases:



    ToggleButtons(description='The mean of the sum:', options=('stays the same', 'increases', 'decreases'), value=…



    ToggleButtons(description='The variance of the sum:', options=('stays the same', 'increases', 'decreases'), va…



    ToggleButtons(description='The covariance of the joint distribution:', options=('stays the same', 'increases',…



    Button(button_style='success', description='Save your answer!', style=ButtonStyle())



    Output()


## Exercise 10:

Given a 6-sided loaded dice. You throw it twice and record the sum. Which of the following statemets is true?


```python
# For Exercise 1, if it expects a number like 0.5
# Assuming it expects you to print it
print(0.5)

import numpy as np
import utils  # Import the utils module here

# Let's assume a loading scenario, e.g., side 6 is three times as likely.
# P(1,2,3,4,5) = p, P(6) = 3p => 5p + 3p = 1 => p = 1/8.
probabilities = np.array([1/8, 1/8, 1/8, 1/8, 1/8, 3/8])
dice_outcomes = np.array([1, 2, 3, 4, 5, 6])

# E[X]
mean_single = np.sum(dice_outcomes * probabilities)
# E[X^2]
ex2 = np.sum(dice_outcomes**2 * probabilities)
# Var(X)
var_single = ex2 - mean_single**2

# For the sum of two independent throws:
mean_sum = 2 * mean_single
var_sum = 2 * var_single
covariance = 0

print(f"Mean of sum: {mean_sum:.3f}")
print(f"Variance of sum: {var_sum:.3f}")
print(f"Covariance: {covariance:.3f}")

# Run this cell to submit your answer
utils.exercise_10()

```

    0.5
    Mean of sum: 8.250
    Variance of sum: 6.719
    Covariance: 0.000



    RadioButtons(layout=Layout(width='max-content'), options=('the mean and variance is the same regardless of whi…



    Button(button_style='success', description='Save your answer!', style=ButtonStyle())



    Output()



```python
# Run this cell to submit your answer
utils.exercise_10()
import numpy as np

```


    RadioButtons(layout=Layout(width='max-content'), options=('the mean and variance is the same regardless of whi…



    Button(button_style='success', description='Save your answer!', style=ButtonStyle())



    Output()


## Exercise 11:

Given a n-sided dice (could be fair or not). You throw it twice and record the sum (there is no dependance between the throws). If you are only given the histogram of the sums can you use it to know which are the probabilities of the dice landing on each side?

In other words, if you are provided with only the histogram of the sums like this one:
<td> <img src="./images/hist_sum_6_side.png" style="height: 300px;"/> </td>

Could you use it to know the probabilities of the dice landing on each side? Which will be equivalent to finding this histogram:
<img src="./images/fair_dice.png" style="height: 300px;"/>



```python
# For Exercise 1, if it expects a number like 0.5
# Assuming it expects you to print it
print(0.5)


# Question: If you are given the histogram of the sums of two throws,
# can you uniquely determine the probabilities of the die landing on each side?

# The answer is YES.

# Explanation:
# This process is known as deconvolution. We can work backward from the smallest sums.
# Let the die probabilities be {p1, p2, ..., pn} for sides {1, 2, ..., n}.
#
# 1. The smallest possible sum is 2 (from 1 + 1).
#    P(Sum=2) = p1 * p1 = p1^2.
#    From the histogram, we know P(Sum=2), so we can find p1 = sqrt(P(Sum=2)).
#
# 2. The next sum is 3 (from 1+2 and 2+1).
#    P(Sum=3) = p1*p2 + p2*p1 = 2*p1*p2.
#    We know P(Sum=3) and p1, so we can solve for p2.
#
# 3. The next sum is 4 (from 1+3, 3+1, and 2+2).
#    P(Sum=4) = 2*p1*p3 + p2^2.
#    We know P(Sum=4), p1, and p2, so we can solve for p3.
#
# We can continue this process iteratively to uniquely find all probabilities p1, p2, ..., pn.


```

    0.5



```python
# Run this cell to submit your answer
utils.exercise_11()
```


    RadioButtons(layout=Layout(width='max-content'), options=('yes, but only if one of the sides is loaded', 'no, …



    Button(button_style='success', description='Save your answer!', style=ButtonStyle())



    Output()


## Before Submitting Your Assignment

Run the next cell to check that you have answered all of the exercises


```python
utils.check_submissions()
```

    All answers saved, you can submit the assignment for grading!


**Congratulations on finishing this assignment!**

During this assignment you tested your knowledge on probability distributions, descriptive statistics and visual interpretation of these concepts. You had the choice to compute everything analytically or create simulations to assist you get the right answer. You probably also realized that some exercises could be answered without any computations just by looking at certain hidden queues that the visualizations revealed.

**Keep up the good work!**



```python

```


```python

```


```python

```
